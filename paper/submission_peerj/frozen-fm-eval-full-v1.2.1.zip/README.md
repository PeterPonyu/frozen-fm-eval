# Frozen-FM-Eval — full reproducibility archive

This Zenodo archive is the **complete reproducibility bundle** for the paper *"Auditing
Frozen Foundation-Model Embeddings: A Leakage-Controlled, Calibration-Aware Evaluation
Protocol Stress-Tested on Single-Cell Genomics"* (Zeyu Fu): all analysis code, the
normalized comparison tables, the self-computed audit outputs, and the figure-generation
scripts, organized by stage.

The distilled, framework-only code + protocol is also on GitHub:
https://github.com/PeterPonyu/frozen-fm-eval . See `PROTOCOL.md` for the evaluation design.

Layout: `scripts/` analysis code · `figures/` make_figs.R + generated TikZ · `results-summary/`
per-stage result tables/JSON · `reports/` meta-analysis corpus and audit notes.
Large embeddings / working data and non-redistributable external per-comparison tables are
not included; primary data are public (GEO GSE174367; CosMx lymph-node release). Code MIT
(LICENSE), docs/tables CC-BY-4.0 (LICENSE-docs).
