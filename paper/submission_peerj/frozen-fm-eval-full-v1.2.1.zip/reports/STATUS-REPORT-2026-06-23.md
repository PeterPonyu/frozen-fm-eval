# 数据进度细查报告 — 单细胞 FM 可靠性元分析 (2026-06-23)

范围：基准/可靠性综述，结论统一 scope 到**零样本 (zero-shot)** FM 态；非临床、非生物发现断言。

---

## 0. 一句话总览
已把"别人发表的实验数据"系统采集成可机读元分析（**12 项研究、10,759 条对比**），并在空间方向用**本机自算**补齐了 FM-vs-基线的真实数字（**2 个零样本空间 FM**）。两大主结论（V1 表征/注释/整合、V5 扰动）+ 新建 cluster-H（空间）均成立且诚实标注 scope。

---

## 1. 别人的实验数据（已采集）

### 1a. 主元分析语料（clusters A+B）
- **清单 37 条**（`extractability-manifest-2026-06-22.json`）= ~30 篇基准研究 + 3 个基础设施(scIB/OpenProblems/scMultiBench) + 4 篇反证。
- **可机读等级**：Tier A=17、B=8、C=11、A-partial=1。
- **真正进入定量对比的**：**12 项研究**，**10,759 条 baseline-vs-FM/DL 对比**（机读 10,732 + 论文人工核录 27）。
- 机读主力：**scPerturBench**（27 方法×29 数据集，扰动）、Ahlmann-Eltze（xlsx Pearson-delta）、PertEval（AUSPC）、Wu-scFM-Bench（scIB，含 HVG/scVI/Harmony/Seurat 基线）、Boiarsky（LR-vs-scGPT）、Kedzierska、scIB metrics.csv(465 行)。
- 论文人工核录（数字只在图/表）：Wong-Pfizer、Bendidi、Csendes、Atti、Systema、Kernfeld。

### 1b. 五个新方向的文献+数据可得性（`directions-expansion-2026-06-23.md`，~40 篇核验）
| 方向 | 覆盖 | 可机读 Tier-A 源（已定位，尚未全部拉取） |
|---|---|---|
| C 不确定性/conformal/校准/弃答 | 10 篇 | Cordero(btaf521)、Theunissen OOD、popV、HCE |
| E/F scATAC-FM + scFM-GRN | 10 篇 | SCARlink(Figshare)、scRegNet(BEELINE GEO)、scATAC protocol atlas |
| D/G 整合过校正 + 轨迹稳定性 | 12 篇 | scIB metrics.csv、RBET(Zenodo)、scIB-E、**veloBench**、Antonsson/Melsted |
| I 泄漏/never-pretrained | 5 篇 | Kedzierska(Zenodo)、Wu(Zenodo)、scTOP(github) |
| H 空间 FM | 9 篇 | **niche-ID 基准仓库（已下数据，见下）** |

> 关键核查纪律：被 403 封锁的 niche-ID 预印本里"Nicheformer 0.123 vs BANKSY 0.611"**未能溯源 → 已撤回**；改为本机自算（见 §2）。

---

## 2. 我们的数据（本机自算，已补齐）

### 2a. A/B 主分析（由采集数据自算）
- 等权重每研究（随机效应）win-rate + bootstrap CI + 效应量；脚本 `normalize.py`/`analyze.py`/`figures.py`，确定性 seed。
- **V1（cluster A，表征/注释/整合）**：简单基线胜 zero-shot scFM **EW 0.887 [0.71,1.0]**（5 研究）；经典降维 0.967。
- **V5（cluster B，扰动）**：**EW 0.653 [0.37,0.87]**（CI 跨 0.5）；限 k≥3 研究 **0.518**；按指标族分层（delta/L2/分布 → 基线胜；绝对相关性 → FM 持平/更优）——量化了 mode-collapse 反证文献的争论。

### 2b. cluster-H 空间（全部本机自算，CosMx 淋巴结 19,718 细胞/4 niche）
14 行，**3 个零样本空间 FM 全部本机跑出**：
- **scGPT-spatial 0.139**（figshare 权重 + 自写加载器，见 §4）
- **Novae 0.124**（本机 5090，照搬基准 `run_novae.ipynb`）
- **Nicheformer 0.012**（HF `aletlvl/Nicheformer` 权重，自定义 tokenizer 直装，HGNC 符号→ENSEMBL，原始计数，已验证稳健）
- 最佳简单基线 nbhd-composition **0.386 = 最强 FM 的 2.78×**；纯 PCA 0.146 也赢所有 FM；CellCharter(深度) 0.253。
- **胜率：非-FM 击败最强 FM 9/11 变体(0.82)、4/4 非退化家族。**

---

## 3. 当前结论（带数字，已核验）
| 结论 | 状态 | 数字 |
|---|---|---|
| V1 零样本 scFM ≤ 简单基线（表征/注释/整合） | **决定性增强** | 0.887 [0.71,1.0]；经典降维 0.967 |
| V5 线性/加性 ≥ DL/FM（扰动） | **成立但依赖指标** | 0.653 [0.37,0.87]；k≥3→0.518 |
| 空间零样本 FM ≤ 简单基线（cluster-H，新；3 个 FM） | **本机自算验证** | 非-FM 9/11 胜；基线 2.78× 最强 FM（scGPT-spatial 0.139/Novae 0.124/Nicheformer 0.012） |
| GRN：raw scFM 信号 ≤ 基因级基线 | 已计算（usage-dependent） | attention 0.70 < Variance 0.88（3/3）；trained-GNN-on-FM 反超 |
| 轨迹/速度：scFM 未被评测 | 开放空白 | veloBench 15 法×17 集，0 个 FM |
| scIB/kBET/LISI 大批次不可靠 | 已核实（caveat 我们 cluster-A 指标） | RBET CV→0；scIB 可被单调刷分 |
| 集成/校准给出可靠 UQ（FM 未审计） | 已核实 | popV 一致性分 8→95%，≤3→<50% |
| scATAC-FM / scFM-GRN 校准审计空白 | **开放空白（最高新颖度）** | 文献 0 篇做过 |

---

## 4. scGPT-spatial 状态（本次"补这个"）— **已用自写加载器跑通 ✅**
- 下载量 **204MB**（figshare `scGPT_spatial_v1.zip`），不大，已下+解压。
- `scgpt` 包确实装不上（torchtext/flash-attn vs torch 2.12+cu130，Blackwell sm_120 必需）——所以**自写最小加载器**（`scripts/spatial_scgpt_fm.py`）：stub 掉 torchtext+flash-attn(+scib/IPython)，复用仓库自带 `get_batch_cell_embeddings` 做精确预处理（slide/gene-mean 归一 + 51-bin + `<cls>` + L2），**用纯 nn 重实现模型**（`use_fast_transformer=False` 路径=标准 post-norm TransformerEncoder，与 flash 层数学等价；合并 `Wqkv`→`in_proj` 重映射）。权重加载干净：**153 张量，0 个关键缺失**。
- **结果：scGPT-spatial 零样本 ARI=0.1387**（最强的 FM），但仍被最佳简单基线 0.386 击败 **2.78×**，且不如 CellCharter(0.253)、连纯 PCA(0.146) 都略胜它。
- cluster-H 现含 **3 个零样本空间 FM**（scGPT-spatial 0.139 / Novae 0.124 / Nicheformer 0.012），全部被简单基线碾压。

---

## 5. 还差什么（gaps）
1. ~~scGPT-spatial~~ **已完成**（§4，自写加载器，ARI 0.139）。cluster-H 现为 3 个 FM。
2. **cluster-H 并入主表**：目前独立（`cluster_H_*`），尚未作为一个 study 折进 `comparisons.csv`/总 win-rate。
3. ~~新方向 Tier-A 机读源~~ **已拉取+计算**（2026-06-23，见 `new-directions-findings-2026-06-23.md`）：GRN(scRegNet+Kendiukhov)、veloBench(轨迹)、RBET+scIB-E(过校正)、popV+HCE(UQ) 落地为 `raw_pulls/{grn,velobench,overcorrection,uq}/` + `ALL_CLUSTERS_SUMMARY.csv`。关键新数：**raw scFM 信号在 GRN 上 3/3 输给基因级基线**（Geneformer attention 0.70 < Variance 0.88）；轨迹/速度**无任何 scFM 被评测=开放空白**；kBET/LISI/scIB 在大批次下不可靠（caveat 我们 cluster-A 的 scIB 输入）；ensemble/校准给出可靠 UQ（popV 一致性分 8→95%）。仍未做：SCARlink(peak-gene)。
4. **多数据集空间 cluster-H**：DLPFC(12 切片)/MOSTA 可把 cluster-H 升级为多数据集带 CI——**需下载新数据集，按你指令暂缓**。
5. **Tier-C 外部数字**（仅在图里，如 Nicheformer 自报 macro-F1）未机读化。

---

## 6. 产物清单（research/sc-fm-benchmark/）
- 综述/报告：`external-benchmark-corpus-*.md`、`extractability-manifest-*.json`、`directions-expansion-*.md`、`meta-analysis-report-*.md`、`cluster-H-spatial-status-*.md`、本报告。
- 数据：`pooled_long.csv`(4782)、`comparisons.csv`(10759)、`winrate_strata.csv`、`effect_sizes.csv`、`cluster_H_spatial_selfcomputed.csv`、`raw_pulls/`(含 588MB lymph.h5ad + scPerturBench 表 + spatial 资产)。
- 脚本：`normalize/analyze/figures` + `spatial_baseline/spatial_expression_baselines/spatial_novae_fm/spatial_nicheformer_fm/cluster_H_winrate`。
- 环境：分析用 `dl`（未污染）；FM 跑在隔离 `nfspatial`(novae/nicheformer) 与 `scgptenv`(scGPT-spatial)。
