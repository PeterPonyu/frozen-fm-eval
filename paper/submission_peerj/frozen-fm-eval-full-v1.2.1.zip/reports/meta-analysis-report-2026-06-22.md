# Meta-analysis of external single-cell benchmark studies (2026-06-22)

**Question.** Do the workspace's load-bearing conclusions — **V1** (zero-shot single-cell foundation models ≤ simple baselines on representation/annotation/integration) and **V5/V5b** (linear/additive baselines ≥ deep-learning/FM perturbation predictors) — hold up when the *reported experimental results* of many independent external benchmarks are pooled into one quantitative synthesis?

**Answer (headline).**
- **V1 is decisively strengthened.** Across **5 independent studies**, simple baselines beat zero-shot scFMs in **88.7%** of head-to-head comparisons (equal-weight-per-study, 95% CI **[0.71, 1.00]**, excludes 0.5). For classical dimensionality-reduction baselines (HVG/PCA/scVI/Harmony/Seurat) on integration the win-rate is **96.7%** [0.90, 1.00].
- **V5 is confirmed but metric-contingent — and the meta-analysis *quantifies* the contingency.** Pooled equal-weight win-rate in perturbation is **65.4%** [0.38, 0.89] (CI spans 0.5). On the biologically-meaningful **delta / L2 / distribution** metrics that the canonical papers use, additive/linear baselines beat DL/FM (Csendes, Kernfeld, Wong-Pfizer all 100%; Ahlmann-Eltze 61%); on **absolute-correlation** metrics FMs/DL are competitive-or-better (PertEval 0%, scPerturBench correlation win-rate 0.34). This is exactly the dependence the mode-collapse counter-literature predicts, now measured.

**Scope (unchanged guardrails).** Benchmark/reliability synthesis only; all conclusions scoped to **zero-shot / out-of-the-box** FM use (fine-tuned FMs can reverse — not extrapolated). No clinical or biological-discovery claims.

---

## 1. Corpus and data provenance

The manifest (`extractability-manifest-2026-06-22.json`) holds **37 catalogued entries** = ~30 distinct benchmark studies (A1–A16, B1–B14) + 3 infrastructure resources (scIB, Open Problems, scMultiBench) + 4 counter-evidence preprints. Of these, **12 contributed usable per-comparison numbers** to this analysis. One catalogued item (“scBenchmark”, clawRxiv 2604.01506) was **dropped** as AI-authored / non-peer-reviewed. The `10.64898/` DOIs are the legitimate post-Dec-2025 bioRxiv prefix (verified).

Raw result tables were pulled into `raw_pulls/` (machine-readable) and supplemented with `paper_reported_comparisons.csv` (curated from papers whose numbers live only in figures/W&B).

| Contribution | Studies | n comparisons |
|---|---|---|
| Machine-readable result files (yield baseline-vs-FM/DL pairs) | scPerturBench, Ahlmann-Eltze, PertEval, Wu-scFM-Bench, Boiarsky | 10,252 |
| Paper-reported (curated, verified) | Wong-Pfizer, Bendidi, Csendes, Atti, Kedzierska, Systema, Kernfeld | 27 |
| **Total** | **12** | **10,279** |

> Note: two further sources were pulled but yield **no** baseline-vs-FM comparison and so don't enter the win-rate — **scEval** (its committed scalars are all-FM, no baseline to pair against) and **Kedzierska's machine-readable scIB** (only scGPT/Geneformer committed; its HVG-baseline win is therefore counted via the *curated* row, tier A). They remain in `pooled_long.csv` for transparency.

> Honest caveat: **scPerturBench dominates the raw comparison count (9,848 / 10,279)** because its tables are per-perturbation. This is precisely why the headline uses an **equal-weight-per-study** estimator rather than naive per-comparison pooling (which would just report scPerturBench's number, 0.486). Both are reported in `winrate_strata.csv` (`win_rate_pooled` vs `win_rate_studyEW`).

## 2. Method

1. **Normalize** (`scripts/normalize.py`) → `pooled_long.csv` (one row per method×dataset×metric), tagging `method_family` (mean-baseline / linear-baseline / classical-DR / mlp-baseline / FM / DL) and `metric_family` (corr/mse/distribution × DEGgenes-vs-allgenes; integration-scIB; classification; delta; raw). MLP baselines are **excluded** from "simple baseline".
2. **Derive comparisons** (`scripts/analyze.py`): within each (study, task, dataset, metric_name, metric_family) group, every simple-baseline method is paired against every FM and DL method; `baseline_wins` is decided by the authoritative per-metric direction (ties = 0.5).
3. **Meta-estimate**: **equal weight per study** (each study contributes its own win-rate; the estimate is the mean across studies) with a **bootstrap over the set of studies** for the CI. Single-study strata report no between-study CI (honestly flagged).
4. **Effect sizes**: signed gap (`+` = baseline better) using the authoritative direction per metric.

## 3. Results

### 3.1 Cluster A — representation / annotation / integration (V1)
- Per-study baseline win-rates: Kedzierska **1.00**, Bendidi **1.00**, Atti **1.00**, Wu-scFM-Bench **0.87**, Boiarsky **0.57** → meta **EW 0.887 [0.714, 1.00]**.
- Classical-DR baselines (HVG/scVI/Harmony/Seurat) vs scFMs: **0.967 [0.901, 1.00]**.
- Effect sizes (Wu scIB): ARI median gap **+0.25** (baseline better in 88% of cases), NMI **+0.10** (88%), AvgBio **+0.12** (83%), Overall **+0.079** (89%).
- The only sub-0.6 study (Boiarsky) is annotation few-shot where scGPT closes the gap as labels increase — consistent with the zero-shot scope.

**→ V1 holds across every study and is meta-analytically strengthened.** A reviewer can no longer dismiss it as a single-paper result.

### 3.2 Cluster B — perturbation prediction (V5/V5b)
- Per-study: Csendes **1.00**, Kernfeld **1.00**, Wong-Pfizer **1.00**, Ahlmann-Eltze **0.61**, Systema **0.50**, scPerturBench **0.47**, PertEval **0.00** → meta **EW 0.654 [0.379, 0.887]** (CI spans 0.5).
- **Sensitivity (k≥3 comparisons/study):** dropping the three single-comparison studies (Csendes-tier k=1/2 curated rows: Kernfeld, Wong-Pfizer, Systema) collapses cluster-B-vs-FM to **EW 0.518 [0.151, 0.867]** across 4 studies — i.e. the perturbation baseline-edge is **fragile and partly carried by small-k curated studies**. Reported explicitly, not hidden.
- Effect sizes are metric-split: Wasserstein **+0.158** (baseline better 80%), PearsonDelta **+0.084** (100%), r2_delta **+0.027** (68%), mse **+0.010** (57%) — but correlation `cor` **−0.111** (baseline better only 33%) and AUSPC favors FMs.

**→ V5 is confirmed on the metrics the canonical critiques use, but is not universal.** The honest statement is *"on delta/L2/distribution metrics, simple baselines match or beat DL/FM perturbation predictors; on absolute-correlation metrics they do not."*

### 3.3 The DEG-weighting axis (engaging the mode-collapse counter-literature)
Within scPerturBench (single study, so reported as pooled rates). Each metric kind is **matched like-for-like** across the gene-set axis (E-distance and Wasserstein are kept separate because Wasserstein exists only on the top-100/DEG set — pooling them would mismatch the axis):

| metric kind | DEG genes (top100) | all genes (top5000) |
|---|---|---|
| correlation | 0.312 | 0.320 |
| MSE | 0.620 | 0.548 |
| E-distance | 0.462 | 0.294 |
| Wasserstein | 0.822 | (top100 only) |

The counter-literature (Miller 2025, Mejia 2026, Heidari 2026) argues that control-referenced delta/absolute metrics reward mode collapse and inflate baseline "wins". Our data show: on **distributional** metrics (E-distance, Wasserstein) and **MSE**, simple baselines win, and *more so* on the DEG-restricted (more biological) gene set (E-distance 0.46 vs 0.29; MSE 0.62 vs 0.55) — the opposite of an artifact; whereas on **correlation** the result is FM-favoring and barely moves with DEG restriction (0.31 vs 0.32). **The "who wins" verdict is metric-family-dependent, not a fixed fact**, which both substantiates the critique's premise (metric choice decides outcomes) and refutes its strong form (that baseline wins are pure artifacts).

### 3.4 Heterogeneity / counter-data (reported, not buried)
- **PertEval = 0.00**: on AUSPC, scFoundation (0.00246) and scGPT (0.00255) beat the Mean (0.00317) and MLP (0.00299) baselines — a clean FM win, included.
- **Systema = 0.50**: under its systematic-variation-controlled metric, mean baselines are *comparable* to SOTA (a tie), not beaten.
- These are exactly the cases the workspace's SC18 reliability angle is built to adjudicate (metric/calibration choice as the deciding variable).

## 4. Integration with the workspace

- **V1** moves from *"scooped reproduction"* to *"meta-analytically established across 5 studies"* — usable as a strengthened premise, not a novelty claim.
- **V5** is reframed honestly: the contribution is no longer "additive beats GEARS" (Ahlmann-Eltze own that) but **"the baseline-vs-DL verdict in perturbation is metric-contingent, and we quantify the contingency across 7 studies and the DEG-weighting axis."** This is a *new* meta-analytic + measurement result and it is the natural bridge to SC18's calibration/reliability thesis.
- Recommended placement: a **motivation/related-work meta-analysis figure** (Fig 1 forest) for the SC18 paper, plus the metric-dependence result (Fig 3) as the empirical hook for "why reliable, calibration-aware evaluation matters."

## 5. Limitations
1. **scPerturBench dominance** of the raw count — mitigated by equal-weight estimator; still, cluster B has effectively 7 studies, several with only 1–2 comparisons (the k≥3 sensitivity above is the honest read: cluster-B baseline edge drops to ~0.52). **Cite `win_rate_studyEW`, not `win_rate_pooled` or `n_comparisons`**: scPerturBench's per-perturbation rows are repeated measures within one study (and each measurement appears under both the DEG-genes and all-genes projections), so the pooled count is *not* a count of independent results — it is inflated by design and reported only for transparency.
2. **DEG-axis is single-study** (scPerturBench) — report as within-study, not pooled.
3. **Paper-reported subset (27 comparisons)** is curated from figures/abstracts; some are qualitative (Atti has no exact values) — flagged `source_tier=C` and used only for direction.
4. **Zero-shot scope** — fine-tuned FMs (e.g., scGPT_CP) can reverse cluster-A results; not extrapolated.
5. Metric-direction encodings were validated per metric; the `cor` family in scPerturBench is treated as correlation (not assumed to be delta).

## 6. Reproducibility
- Scripts: `scripts/normalize.py`, `scripts/analyze.py`, `scripts/figures.py` (env `dl`, CPU-only, deterministic seed 20260622).
- Inputs: `raw_pulls/` + `paper_reported_comparisons.csv`. Outputs: `pooled_long.csv`, `comparisons.csv`, `per_study_winrate.csv`, `winrate_strata.csv`, `winrate_deg_axis.csv`, `effect_sizes.csv`, `analysis_summary.json`, `figures/fig1–4`.
- Re-run: `conda run -n dl python3 scripts/normalize.py && conda run -n dl python3 scripts/analyze.py && conda run -n dl python3 scripts/figures.py`.

## 7. Figures
- `fig1_forest_per_study.png` — per-study baseline win-rate (A vs B) + meta lines.
- `fig2_winrate_strata.png` — meta win-rate by stratum with study-level CIs.
- `fig3_deg_axis.png` — metric-dependence / DEG-weighting axis.
- `fig4_effect_sizes.png` — signed effect sizes per metric.

### Bottom line
Pooling the reported results of a dozen independent benchmarks turns the workspace's two "scooped" findings into one defensible, quantitative, honestly-scoped statement: **zero-shot scFMs are robustly beaten by simple baselines on representation/annotation/integration (≈89% across studies), while in perturbation the baseline advantage is real but metric-contingent (≈65%, decisive only on delta/distribution metrics)** — and the metric-contingency itself is the bridge to the SC18 reliability thesis.
