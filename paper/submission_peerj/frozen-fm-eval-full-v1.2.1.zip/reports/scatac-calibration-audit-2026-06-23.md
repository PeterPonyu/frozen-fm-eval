# scATAC-FM calibration/reliability audit — first of its kind (2026-06-23)

**Rank-1 whitespace filled.** The literature sweep confirmed **no published calibration / reliability / conformal / abstention audit exists for any scATAC foundation model or scATAC cell-type classifier**. This is the first — self-computed on local data, FM-free (peak-LSI probe), fully reproducible. It ports the workspace's SC18 scRNA protocol to chromatin and returns a **novel modality contrast**.

Scope: zero-shot/out-of-the-box reliability of a peak-LSI cell-type probe; benchmark-reliability only; no clinical claims.

---

## Headline
**The standard (FM-free) scATAC cell-type annotation pipeline is markedly MORE reliable under domain shift than the scRNA scGPT pipeline.** On GSE174367 snATAC (human brain, 130,418 cells, 20 samples, 7 major types), an FM-free peak-LSI + logistic probe is **excellently calibrated (ECE 0.0055)** and its split-conformal coverage **holds under both cross-sample and cross-disease shift** — in stark contrast to the scRNA SC18 result where zero-shot scGPT conformal coverage **collapses by 0.123** under cross-batch shift. (Caveat: scATAC side = linear probe, scRNA side = FM; see caveats 5–6.)

| regime | conformal coverage (target 0.90) | gap |
|---|---|---|
| scATAC random | 0.901 | — |
| scATAC **cross-sample** | 0.908 | **−0.007** [−0.011, −0.003] |
| scATAC **cross-diagnosis (Control→AD)** | 0.922 (vs Control-held 0.894) | **−0.028** |
| scRNA SC18 cross-batch (scGPT) | 0.777 | **+0.123** (collapse) |

→ **No coverage collapse anywhere in scATAC.** (Fig 1.)

## Full results (`scatac_results/scatac_audit_result.json`)
- **Calibration:** ECE **0.0055** (Fig 2 reliability diagram near-diagonal).
- **Probe:** cross-sample acc **0.983**, macro-F1 **0.966** (audit 50%-sample split; the probe-script's 25%-holdout split gives 0.99/0.977).
- **Confidence is meaningful & depth-independent:** partial-corr(confidence, correctness | log-total-fragments + log-n-peaks + sample) = **0.4775** [0.460, 0.495] ≈ raw 0.4774 → **fragment depth / n-peaks / sample explain essentially none** of the confidence↔correctness signal. (Contrast: in scRNA, depth was a real confounder needing deconfounding.)
- **Selective abstention:** AURC **0.001**, acc@80%-coverage **0.999** (Fig 3).
- **Rare-type abstention bias persists** (mirrors SC18): PER.END (rare, n=1945) rejected **0.58** vs overall **0.20** at the 80%-coverage threshold — a fairness cost that must be disclosed.
- **Negative controls pass:** label-shuffle and permuted-LSI both collapse to chance (0.4525); real probe 0.983 ≫ chance.

## Interpretation
Chromatin accessibility encodes brain **major-type** identity so robustly that a simple linear probe is well-calibrated and conformally reliable across donors and even across disease state — the exchangeability violation that breaks scRNA scGPT conformal coverage does **not** materialize here. The reliability lens (SC18) thus yields a **modality-dependent verdict**: the scRNA "calibration collapses under batch shift" warning does **not** transfer to scATAC coarse-type annotation.

## Honest caveats
1. **Easy task / label circularity:** probe accuracy is ~98% and the `Cell.Type` labels are clustering-derived from (likely) the same ATAC modality → the task is intrinsically easy and partially circular (same limitation as SC18). The no-collapse result is strongest read as: *for the standard major-type annotation task, scATAC calibration is robust* — not that scATAC is universally easy (fine subtypes / peak-gene linkage / motif tasks are untested and likely harder).
2. **One dataset, FM-free probe.** This is the peak-LSI probe (no scATAC FM weights — ChromFound/EpiFoundation not run). It establishes the *baseline-method* reliability; auditing an actual scATAC FM's calibration is the natural next step (still zero published).
3. **Coverage gaps are slightly negative** (slightly over-covered) — i.e. conformal is, if anything, conservative cross-shift; no anti-conservative failure.
4. **Library conformal cross-check PASSED** (`scatac_verify.py`): custom LAC = independent recompute = **crepes** = **mapie 1.4 (SplitConformalClassifier)** = **0.9079** (identical to 16 digits) on the same cal/test sets. The `"skip:ImportError"` in the audit JSON is only because the audit used the removed legacy `MapieClassifier` API; verify.py uses the current API and closes the gate.
5. **Apples-to-oranges guard:** the scATAC side is an **FM-free linear peak-LSI probe**, the scRNA SC18 side is a **zero-shot scGPT FM** — so the contrast mixes a modality difference with a method difference. The honest minimal claim: *with the standard non-FM annotation pipeline, scATAC major-type calibration is robust to shift where the scRNA scGPT pipeline is not.* Auditing an actual scATAC FM (still zero published) is the clean apples-to-apples follow-up.
6. **Partly expected, not magic:** at ~98% base accuracy the LAC sets are near-singletons (avg size ~0.91), so coverage is mechanically stable — the no-collapse result is a *consequence of task ease* (coarse chromatin-separable types), not a surprising deep property of chromatin. The contribution is establishing this quantitatively as the first such audit + the depth-independence and rare-type-bias findings.

## Relation to the meta-analysis
New cluster **"scATAC reliability"** (call it cluster I-ATAC). Unlike clusters A/B/H (simple baseline ≥ FM on *performance*), this is a **reliability/calibration** result: it shows the SC18 calibration-collapse finding is **modality-specific** (scRNA yes, scATAC no). It both (a) fills the Rank-1 published whitespace and (b) sharpens the workspace's reliability thesis by bounding where it applies.

## FM arm — ChromFound (real scATAC FM, zero-shot) head-to-head (added 2026-06-23)
The apples-to-apples follow-up **succeeded** (initially thought blocked; the wall was only nvcc-12-vs-cu130 + a torch-2.9/mamba kernel ABI clash, both sidestepped by a pure-torch run). ChromFound's own modules + pretrained weights loaded **exactly (0 missing / 0 unexpected, 110 tensors)**; Mamba run via `selective_scan_ref` (exact recurrence) + flash→SDPA. Zero-shot embeddings on GSE174367 (20,002 cells), same SC18 audit:

**Fair, MATCHED-condition comparison (same 20,002 cells; `scatac_fm_matched.json`) — corrected after adversarial verification.** A naive "FM 0.834 vs full-LSI 0.983, ECE 17× worse" headline was an **artifact of peak-subset + dimensionality**, NOT a genuine ChromFound failure. The honest matched table:

| substrate (same 20k cells) | acc | ECE | x-sample cov |
|---|---|---|---|
| **ChromFound FM (2048-d, faithful recipe)** | 0.834 | 0.094 | 0.904 |
| raw top-2048 log-TF-IDF (= the FM's own input, 2048-d) | 0.850 | 0.088 | 0.909 |
| LSI top-2048 → SVD-50 (matched peaks) | 0.863 | **0.007** | 0.903 |
| LSI full-peak → SVD-50 (reference) | **0.968** | 0.011 | 0.914 |

**Correct findings:**
1. **ChromFound's zero-shot embedding does NOT beat its own raw TF-IDF input** (acc 0.834 vs 0.850; ECE 0.094 vs 0.088) — under the faithful mean-pool recipe the FM adds nothing over the input on this cell-type task. *This* is the real "simple ≥ FM" result for scATAC, stated honestly.
2. The **ECE gap is a dimensionality effect**, not FM-vs-baseline: any 2048-d representation (FM or raw) is poorly calibrated (~0.09); SVD-to-50 (LSI) is what restores calibration (~0.01).
3. The **accuracy gap vs full-LSI (0.968) is mostly the peak-subset** (matched top-2048 LSI = 0.863), not the FM.
4. **Conformal coverage holds (~0.90) for all four substrates** (no collapse) — the scRNA-vs-scATAC modality-robustness contrast stands regardless of representation.

**Caveats (must carry):** ChromFound run on a **disclosed top-2048-peak subset** (its design is full-genome; full-genome needs the CUDA selective-scan kernel, torch-2.9-incompatible here) + 20k-cell subsample; faithful **mean-over-hidden pooling** per its `cell_embedding.py` (a mean-over-peaks 128-d pooling is untested and might differ). Weights/architecture exact (0 missing/0 unexpected). Run is pure-torch Mamba (`selective_scan_ref`, exact) + SDPA + retained Triton RMSNorm (exact). The honest scope: *a faithful zero-shot ChromFound embedding provides no gain over its raw input here*; this does not bound full-genome / fine-tuned ChromFound. (Fig 4.)

## Artifacts
- `scatac_results/scatac_audit_result.json`, `scatac_lsi.npz`, `figures/fig1–3`.
- scripts: `scatac_probe.py`, `scatac_audit.py`, `scatac_figures.py`, `scatac_verify.py`, **`scatac_chromfound_embed.py`** (FM embed), **`scatac_fm_audit.py`** (FM audit), **`scatac_fm_compare.py`** (fig4) (env `dl`, seed 20260623).
- data: `raw_pulls/scatac/atac_cell_meta.csv.gz` (GEO supplementary) + local GSE174367 peak matrix.
