# External benchmark corpus for meta-analysis (2026-06-22)

**Question answered:** Can we retrieve a large set of single-cell benchmark studies and *actually obtain their raw experimental results* to fold into a meta-analysis that strengthens this workspace's conclusions?

**Verdict: YES — strongly feasible.** A single recon sweep (3 parallel agents) surfaced **~35 distinct benchmark studies** (vs. ~14 currently cited in `DEEP-REVERIFY` / `SAMPLED_PAPERS`), of which **~18–20 are Tier A: per-method × per-dataset × per-metric result files are publicly downloadable** (GitHub raw CSV, Zenodo RDS/h5ad, Figshare, interactive leaderboards with export). Proof-of-concept: `raw_pulls/scib_metrics.csv` (465 rows, 14 metrics × 16 methods × 13 datasets) was pulled in one `curl`.

Scope decisions locked with user (2026-06-22): **both clusters (A + B)**, **reported-metrics meta-analysis depth** (harvest reported tables + framework result files; no GPU/weight-gated re-runs this pass), **deliverable = retrieve + build extraction table**.

> Scope/honesty guardrails (unchanged from AGENTS.md): benchmark/reliability synthesis only; conclusions stay scoped to **zero-shot / out-of-the-box** FM state (fine-tuned FMs can reverse — do not extrapolate); no clinical/biological-discovery claims.

---

## Why this strengthens the workspace's "scooped" conclusions

`DEEP-REVERIFY` flags **V1** (zero-shot scFM ≤ PCA/scVI/HVG) and **V5/V5b** (additive baseline beats GEARS) as *scooped* — because each individual paper already shows it. **No one has pooled them.** A quantitative synthesis across ~35 papers and hundreds of method×dataset comparisons (pooled win-rate of simple baselines, effect sizes with CIs, moderator analysis by task/tissue/metric) is a **genuinely novel contribution** that converts the scooped reproductions into a meta-analytic headline — and it leans on existing strengths (the SC18 reliability protocol + local re-run capability).

**Crucial caveat surfaced by the sweep (must be designed in):** a counter-literature argues the "mean/linear baseline wins" result is partly an artifact of *control-referenced delta metrics that reward mode collapse* (Miller 2025 `10.1101/2025.10.20.683304`; Mejia 2026 `arXiv:2506.22641`; Heidari 2026 `10.64898/2026.02.14.705879`). The meta-analysis must (a) stratify by metric family (raw vs. delta vs. DEG-weighted/calibrated), and (b) report the counter-result honestly. This is *also an opportunity*: SC18's calibration/reliability angle is exactly the lens that adjudicates this dispute.

---

## Cluster A — representation / annotation / integration: zero-shot scFM ≤ simple baselines

| # | Study | DOI / ID | Direction (baseline vs FM) | Tier | Raw-result location |
|---|---|---|---|---|---|
| A1 | Kedzierska 2025, *Genome Biology* (already cited) | 10.1186/s13059-025-03574-x | HVG > Geneformer/scGPT on clustering; Geneformer last on integration | **A** | github.com/microsoft/zero-shot-scfoundation; Zenodo 10.5281/zenodo.15123462; Supp S1–S7 |
| A2 | Boiarsky/Sontag 2024, *Nat Mach Intell* (+2023 bioRxiv); "one PCA" arXiv lineage | 10.1038/s42256-024-00949-w; bioRxiv 10.1101/2023.10.19.563100 | L1-logistic regression matches/beats scBERT & scGPT (annotation) | **A** | github.com/clinicalml/sc-foundation-eval; Zenodo 10.5281/zenodo.13372104 |
| A3 | Bendidi 2024 "one PCA still rules them all", NeurIPS AIDrugX WS | arXiv:2410.13956 | PCA/scVI ≫ Geneformer/scGPT/CellPLM/UCE on perturbation-rep tasks | **A** | github.com/valence-labs/Tx-Evaluation; Zenodo 14037432/14037465/14039051 |
| A4 | Atti & Subramaniam 2025, bioRxiv | 10.1101/2025.06.26.661767 | Seurat v5 > scGPT/Geneformer/SCMAMBA-2 (even w/o noise) | C | figures/abstract only; no repo found |
| A5 | Han 2026 "real-world RNA-seq integration", bioRxiv | 10.64898/2026.04.17.719314 | scVI #1 (Leximax) over scGPT/scFoundation/scMulan/CellFM, 1.5M cells | C | text/figures; repo unconfirmed |
| A6 | Hou 2026 "unified framework, 13 FMs × 50+ datasets" | 10.64898/2026.01.06.698060; PMC12803055 | PCA competitive/preferable; no consistent FM advantage | B | Nextflow framework; supp figs; result CSVs unconfirmed |
| A7 | BioLLM (Qiu 2025), *Patterns* | 10.1016/j.patter.2025.101326 | standardized scFM eval (scGPT robust; scBERT weak) | B | github.com/BGIResearch/BioLLM; Zenodo 15597639 (weights only) |
| A8 | Kendiukhov 2026, SSRN | 10.2139/ssrn.6577900 | frozen ESM2-3B (no SC training) matches scFMs on many gene probes | C | preprint figures only |
| A9 | Wu 2025 "Biology-driven insights", *Genome Biology* (PMID 41044630) | 10.1186/s13059-025-03781-6 | no scFM dominates; simpler ML adapts better; FRoGS > scFM gene-level | B | github.com/wujialu/scFM-Bench; Zenodo 10.5281/zenodo.17054467 |
| A10 | Liu/Zhao 2026 "Evaluating Utilities of FMs" (scEval), *Adv. Science* (PMID 41869863) | 10.1002/advs.202514490 | top scFMs don't surpass task-specific; PCA ARI 0.65 vs scFM ~0.57 | **A** | github.com/HelloWorldLTY/scEval |
| A11 | scELMo, Liu 2026, *Patterns* (PMID 41726097) | 10.1016/j.patter.2025.101431 | LLM embeddings (no SC pretraining) match scGPT/Geneformer | B | github.com/HelloWorldLTY/scELMo; Supp Data S1–S4 (xlsx scores) |
| A12 | DenAdel/Crawford 2026, *Nat Methods* (data scaling) | 10.1038/s41592-026-03120-y; bioRxiv 10.1101/2024.12.13.628448 | perf saturates ~1% corpus; no model beats PCA/LR across tasks | **B** (corrected) | github.com/microsoft/scFM-dataselection — CODE + diversity/timing only; **per-task metric tables NOT committed** (uncommitted `metrics_csvs/`); Nature supp = paywalled figure PDF. Numbers need pipeline run (scTab+weights) → contributed 0 comparisons |
| A13 | CellBench-LS, Xu 2026, bioRxiv (low-supervision) | 10.64898/2026.04.01.714123 | PCA/scVI competitive in quantitative tasks | C | repo unconfirmed |
| A14 | Zero-shot dynamics benchmark 2026, bioRxiv | 10.64898/2026.03.10.710748 | HVG+OT > zero-shot scFM on trajectory/dynamics | C | repo unconfirmed |
| A15 | CytoType (species-specific small models) 2026, bioRxiv | 10.64898/2026.03.16.711196 | small ESM-2 linear model ≈/> large scFM (F1 gap 0.053) | C | repo unconfirmed |
| A16 | scBenchmark 2026 (8 methods × 7 tasks × 24 datasets, 3.2M cells) | clawRxiv 2604.01506 (UNVERIFIED) | scFM vs Seurat v5/scVI/scANVI/CellTypist | B? | github.com/scbenchmark/scbenchmark (URLs unverified) |

### Cluster A infrastructure (baseline reference tables — no scFM, but provide the classical-method arm)
| # | Resource | DOI / ID | Tier | Raw-result location |
|---|---|---|---|---|
| A-I1 | **scIB / scib-reproducibility**, Luecken 2022, *Nat Methods* | 10.1038/s41592-021-01336-8 | **A (direct CSV)** | raw.githubusercontent.com/theislab/scib-reproducibility/main/data/metrics.csv (+ metrics_atac.csv) — **pulled → raw_pulls/scib_metrics.csv** |
| A-I2 | Open Problems for Single-Cell, Luecken 2025, *Nat Biotechnol* | 10.1038/s41587-025-02694-w | A/partial | openproblems.bio/results/...; S3 openproblems-bio bucket; task repos |
| A-I3 | scMultiBench, Zuo 2025, *Nat Methods* (40 methods × 86 datasets) | 10.1038/s41592-025-02856-3 | **A** | shiny.maths.usyd.edu.au/scMultiBench/; Zenodo 15385334; Figshare 29035586 |

---

## Cluster B — perturbation-response prediction: linear/additive ≥ DL/FM

| # | Study | DOI / ID | Direction + key numbers | Tier | Raw-result location |
|---|---|---|---|---|---|
| B1 | Ahlmann-Eltze 2025, *Nat Methods* (already cited) | 10.1038/s41592-025-02772-6; bioRxiv 10.1101/2024.09.16.613342 | additive beats all 7 DL on double-pert; linear best single-pert | **A** | github.com/const-ae/linear_perturbation_prediction-Paper; Zenodo 14832393 → 16092690 (RDS+TSV) |
| B2 | Csendes 2025, *BMC Genomics* | 10.1186/s12864-025-11600-2 | Train-Mean PearsonΔ (0.711/0.557/0.373/0.628) > scGPT > scFoundation on all 4 | B | github.com/turbine-ai/PerturbSeqPredBenchmark (notebooks, Git LFS) |
| B3 | PertEval-scFM, Wenteler 2025, *ICML* | bioRxiv 10.1101/2024.10.02.616248; PMLR v267 | scFM embeddings ⊁ MLP baseline under shift; Geneformer/scGPT negative ΔAUSPC | **A** | github.com/aaronwtr/PertEval |
| B4 | Vollenweider & Bühlmann 2026 "SBB principles" | 10.64898/2026.04.20.719650 | DL/FM "often fail to meaningfully surpass linear" across 7 datasets | **A** | github.com/michavol/sbb-perturbation-benchmark (detailed_metrics.csv per run) |
| B5 | PertDiffBench 2026 | 10.64898/2026.06.13.732013 | diffusion ⊁ scGen; scVI > STATE in several settings | C | repo not found |
| B6 | Kernfeld 2025 "expression forecasting", *Genome Biology* | 10.1186/s13059-025-03840-y; bioRxiv 10.1101/2023.07.28.551039 | "uncommon" for methods to beat mean baseline; 11 datasets | **A** | github.com/ekernf01/perturbation_benchmarking + pereggrn; Zenodo 15115945 |
| B7 | Systema, Viñas 2025, *Nat Biotechnol* | 10.1038/s41587-025-02777-8 | PearsonΔ ~r0.91–0.95 w/ systematic variation; mean ≈ SOTA | **A** | github.com/mlbio-epfl/systema; Zenodo 15746994 |
| B8 | Wong/Pfizer 2025 "Simple controls exceed best DL", *Bioinformatics* | 10.1093/bioinformatics/btaf317; bioRxiv 10.1101/2025.01.06.631555 | CRISPR-informed mean vs GEARS +0.08 (p9.3e-4), vs scGPT +0.11; rank 4.7–214× better | **A** | github.com/pfizer-opensource/perturb_seq; Zenodo 15352937 (verified reachable) |
| B9 | **scPerturBench**, Wei 2025, *Nat Methods* (27 methods × 29 datasets) ★ flagship | 10.1038/s41592-025-02980-0 | linear baseline competitive/superior; no model dominates | **A** | github.com/bm2-lab/scPerturBench; bm2-lab.github.io/scPerturBench-reproducibility (download raw outputs); Zenodo 14607156 + 14638780 (verified reachable) |
| B10 | PerturBench (Altos), Wu 2024, arXiv | arXiv:2408.10609 | simpler architectures competitive; mode collapse in CPA/published models | B | github.com/altoslabs/perturbench |
| B11 | scPerturb (data resource), Peidli 2024, *Nat Methods* | 10.1038/s41592-023-02144-y | harmonized 44-dataset Perturb-seq corpus + E-distance | **A** | scperturb.org; Zenodo 7041848 (RNA) / 7058381 (ATAC) |
| B12 | Szałata 2024 NeurIPS D&B (chemical pert competition) | openreview WTI4RJYSVm | mean-per-gene controls in official eval; winners = ensembles | **A** | openproblems leaderboard |
| B13 | scArchon, Radig 2025, bioRxiv/*Genome Biology* | 10.1101/2025.06.23.661046 | several tools underperform linear/control; biological-fidelity check | **A** | github.com/hdsu-bioquant/scArchon (Snakemake) |
| B14 | GGE eval, Rubbi 2026, arXiv | arXiv:2603.11244 | standardized generative-model eval (scVI/scGen/CPA/GEARS/STATE…) | **A** | github.com/AndreaRubbi/GGE; PyPI gge-eval |

### Cluster B counter-evidence (MUST address in meta-analysis design)
| # | Study | DOI / ID | Claim |
|---|---|---|---|
| C1 | Miller 2025, bioRxiv | 10.1101/2025.10.20.683304 | DL **does** beat baselines under dynamic-range-fraction (well-calibrated) metric; MSE/PearsonΔ poorly calibrated |
| C2 | Mejia 2026, arXiv | arXiv:2506.22641 | mean "wins" because delta metrics reward mode collapse; WMSE/R²_w(Δ) flips it |
| C3 | Heidari 2026, bioRxiv | 10.64898/2026.02.14.705879 | corr/distance metrics confounded by scale/sparsity/dimensionality |
| C4 | Li 2024 "In Silico Gene Perturbation", bioRxiv | 10.1101/2024.12.20.629581 | 17 datasets / 10 methods; zero-shot remains hard (neutral-to-supporting) |

---

## Extractability summary

- **Tier A (raw per-method×per-dataset metric files downloadable now):** A1, A2, A3, A10, A-I1, A-I2, A-I3, B1, B3, B4, B6, B7, B8, B9, B11, B12, B13, B14 → **~18 sources.** (A12 downgraded to B on 2026-06-23 — its result tables are uncommitted; see corrected row.)
- **Tier B (numbers in supp tables / paper-embedded, reproducible via repo):** A6, A7, A9, A11, A12, A16, B2, B10 → ~8.
- **Tier C (figures/abstract only):** A4, A5, A8, A13, A14, A15, B5, C1–C4 → ~10 (still usable for vote-counting / extracted point estimates).

**Best immediate targets** (machine-readable, license-clean, directly on-point):
1. `scib_metrics.csv` (already pulled) — classical-method integration arm, 465 rows.
2. **scPerturBench** Zenodo + reproducibility site — the single richest perturbation table (27×29).
3. Ahlmann-Eltze Zenodo RDS/TSV — the canonical linear-beats-GEARS predictions.
4. Wong/Pfizer Zenodo — quantified mean-vs-GEARS/scGPT effect sizes with p-values.
5. Bendidi Tx-Evaluation — PCA-vs-FM representation numbers.

## Proposed normalized schema for the pooled table (next pass)
`study_id, cluster (A/B), task, dataset, n_cells, n_perts, method, method_family (FM | linear/additive | classical-DR | LLM-embed | other), metric_name, metric_family (raw | delta | DEG-weighted/calibrated | integration-scIB), value, higher_is_better, baseline_or_model, source_tier, source_url, license, verified (Y/N)`.
Derived outputs: per-comparison `baseline_wins` (bool, metric-direction aware) → pooled win-rate + bootstrap CI, stratified by task / metric_family / tissue; random-effects effect-size where comparable metrics exist.

## Verification status / liabilities
- DOIs for all seed + most discovered papers cross-checked via PubMed/PMC/CrossRef by the sweep agents; a handful of 2026 bioRxiv `10.64898/...` items confirmed only via web cross-reference (403 on direct fetch) — re-verify with `verify_doi` before citing.
- `scBenchmark` (A16) URLs are **unverified** (leaderboard/Zenodo did not resolve) — treat as unconfirmed until checked.
- Endpoints probed live and returning 200 on 2026-06-22: scIB raw CSV, Zenodo 16092690, Zenodo 14607156, Pfizer repo.
- Machine-readable target list: `extractability-manifest-2026-06-22.json`.
